package com.demo.webrtc.models

class UserLoginRequest(
    var name: String,
    var email: String,
    var phone: String,

    )