package com.muzville.ui.auth.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.demo.newsapplication.base.BaseViewModel
import com.demo.newsapplication.base.SingleLiveEvent
import com.demo.webrtc.models.UserInfo
import com.demo.webrtc.models.UserLoginRequest
import kotlinx.coroutines.launch

class LoginActivityViewModel : BaseViewModel() {
    private val _login = SingleLiveEvent<UserInfo>()
    val login: LiveData<UserInfo> = _login



    fun login(userLogin: UserLoginRequest) {
        viewModelScope.launch {
            displayLoader()
            processDataEvent(api1Repository.login(userLogin)) {
                _login.postValue(it)
            }
        }
    }
}