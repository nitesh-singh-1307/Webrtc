package com.demo.newsapplication.utils

const  val NEWSDETAILS = "newsdetails"
const val BUS_EVENT_PROFILE_UPDATED = "EVENT_PROFILE_UPDATED"
