package com.demo.webrtc.models

data  class UserLoginRequest(
    var name: String,
    var email: String,
    var phone: String,

    )