package com.muzville.ui.auth.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.demo.newsapplication.base.BaseViewModel
import com.demo.newsapplication.base.SingleLiveEvent
import com.demo.webrtc.models.UserInfo
import com.demo.webrtc.models.UserLoginRequest
import kotlinx.coroutines.launch

class LoginActivityViewModel : BaseViewModel() {
    private val _login = SingleLiveEvent<UserLoginRequest>()
    val login: LiveData<UserLoginRequest> = _login



    fun login() {
        viewModelScope.launch {
            displayLoader()
            processDataEvent(api1Repository.login()) {
                _login.postValue(it)
            }
        }
    }
}